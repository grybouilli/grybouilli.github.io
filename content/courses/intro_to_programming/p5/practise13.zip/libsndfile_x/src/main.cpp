#include <sndfile.h>

int main(int argc, char ** argv) {
    
    return 0;
}