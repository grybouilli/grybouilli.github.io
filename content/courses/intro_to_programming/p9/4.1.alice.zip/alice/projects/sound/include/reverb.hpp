#pragma once

#include <vector>

std::vector<float> reverb(const std::vector<float>& dry_signal,
                          const std::vector<float>& reverb_src);