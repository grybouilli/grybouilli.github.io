#include <iomanip>
#include <iostream>
#include <vector>

std::vector<float> reverb(const std::vector<float>& dry_signal,
                          const std::vector<float>& reverb_src);

int main() {
    try {
        // Example dry signal (an impulse)
        std::vector<float> dry_signal = {1.0f, 0.0f, 0.0f, 0.0f};

        // Example impulse response
        std::vector<float> impulse_response = {0.8f, 0.4f, 0.2f, 0.1f};

        std::vector<float> wet_signal = reverb(dry_signal, impulse_response);

        std::cout << "Output signal:\n";

        for (float sample : wet_signal) {
            std::cout << std::fixed << std::setprecision(3) << sample << ' ';
        }

        std::cout << '\n';
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << '\n';
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}