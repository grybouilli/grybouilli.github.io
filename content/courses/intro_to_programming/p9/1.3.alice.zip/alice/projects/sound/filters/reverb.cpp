#include <algorithm>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <vector>
// Linear convolution of dry_signal with reverb_src (impulse response)
std::vector<float> reverb(const std::vector<float>& dry_signal,
                          const std::vector<float>& reverb_src) {
    // Empty input checks
    if (dry_signal.empty()) throw std::invalid_argument("dry_signal is empty.");

    if (reverb_src.empty()) throw std::invalid_argument("reverb_src is empty.");

    // Prevent pathological allocations
    constexpr std::size_t max_samples =
        std::numeric_limits<std::size_t>::max() / sizeof(float);

    if (reverb_src.size() > max_samples)
        throw std::overflow_error("Output vector would be too large.");

    const std::size_t output_size = reverb_src.size();

    std::vector<float> wet_signal(output_size, 0.0f);
    const size_t       n = dry_signal.size();
    // Linear convolution
    for (std::size_t i = 0; i < wet_signal.size(); ++i) {
        for (std::size_t j = 0; j < reverb_src.size(); ++j) {
            wet_signal[i] +=
                (n - j - 1 < 0 ? 0 : dry_signal[n - j - 1]) * reverb_src[j];
        }
    }

    return wet_signal;
}
