#pragma once

#include <vector>

#if defined(_WIN32) || defined(WIN32) || defined(__CYGWIN__) || \
    defined(__MINGW32__) || defined(__BORLANDC__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

EXPORT
std::vector<float> reverb(const std::vector<float>& dry_signal,
                          const std::vector<float>& reverb_src);