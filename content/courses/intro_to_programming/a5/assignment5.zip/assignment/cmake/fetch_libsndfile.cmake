include(FetchContent)
include(cmake/fetch_ffw3.cmake)   


get_target_property(FFTW3_INCLUDE_DIR fftw3 SOURCE_DIR)

set(FFTW3_FOUND        TRUE  CACHE BOOL   "" FORCE)
set(FFTW3_LIBRARIES    fftw3 CACHE STRING "" FORCE)
set(FFTW3_INCLUDE_DIRS "${ffw3_SOURCE_DIR}/api" CACHE PATH "" FORCE)

set(BUILD_SHARED_LIBS ON CACHE BOOL "" FORCE)

if(WIN32)
    include(FetchContent)

    FetchContent_Declare(
        sndfile
        URL https://github.com/libsndfile/libsndfile/releases/download/1.2.2/libsndfile-1.2.2-win64.zip
    )
    set(ENABLE_PACKAGE_CONFIG OFF CACHE BOOL "" FORCE)
    set(BUILD_TESTING         OFF CACHE BOOL "" FORCE)
    set(BUILD_PROGRAMS        OFF CACHE BOOL "" FORCE)
    set(BUILD_EXAMPLES        OFF CACHE BOOL "" FORCE)
    FetchContent_MakeAvailable(sndfile)

    add_library(SndFile::sndfile SHARED IMPORTED GLOBAL)

    set_target_properties(SndFile::sndfile PROPERTIES
        IMPORTED_LOCATION
            "${sndfile_SOURCE_DIR}/bin/sndfile.dll"
        IMPORTED_IMPLIB
            "${sndfile_SOURCE_DIR}/lib/sndfile.lib"
        INTERFACE_INCLUDE_DIRECTORIES
            "${sndfile_SOURCE_DIR}/include"
    )
else()
    FetchContent_Declare(
        libsndfile
        GIT_REPOSITORY https://github.com/libsndfile/libsndfile
        GIT_TAG        1.2.2
    )

    set(ENABLE_PACKAGE_CONFIG OFF CACHE BOOL "" FORCE)
    set(ENABLE_EXTERNAL_LIBS OFF CACHE BOOL "" FORCE)
    set(BUILD_TESTING         OFF CACHE BOOL "" FORCE)
    set(BUILD_PROGRAMS        OFF CACHE BOOL "" FORCE)
    set(BUILD_EXAMPLES        OFF CACHE BOOL "" FORCE)

    FetchContent_MakeAvailable(libsndfile)
endif()
