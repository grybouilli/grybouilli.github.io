#pragma once

#include <sndfile.h>

#include <string>
#include <vector>

// Load all samples from a .wav file. Close that file once read.
// Returns an empty vector and prints an error if the file cannot be opened.
std::vector<float> load_wav(const std::string& path, SF_INFO& info);

// Write samples to a .wav file using info as the format template.
// Returns false and prints an error if the file cannot be created.
bool save_wav(const std::string&        path,
              const std::vector<float>& samples,
              SF_INFO&                  info);

void apply_gain_mult(std::vector<float>& samples, float factor);

void apply_concatenate(std::vector<float>&             samples,
                       const std::vector<std::string>& extra_paths,
                       SF_INFO&                        info);