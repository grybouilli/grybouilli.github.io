#pragma once

#include <string>
#include <vector>

std::vector<std::string> split(std::string s, const std::string& delimiter);

bool parse_config(const std::string&        path,
                  std::string&              input_path,
                  std::string&              output_path,
                  std::vector<std::string>& commands);