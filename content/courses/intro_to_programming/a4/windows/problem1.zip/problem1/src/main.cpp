#include <image_manips.hpp>
#include <iostream>

bool is_color(const std::string word) {
    return word == "red" || word == "green" || word == "blue";
}

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cout << "usage: ./img_tweaker <input_file> <output_file> <command"
                     "> [ args ...]"
                  << std::endl;

        return 1;
    }

    std::string input_file_path  = argv[1];
    std::string output_file_path = argv[2];
    std::string command          = argv[3];

    if (command == "tobw") {
        // Step 2.1
        // RGBImage image = ... complete me ... ; // load the RGB image
        // BWImage bw_image = ... complete me ... ; //  convert your RGB image to a black and white image
        // ... complete me ... -> save your black and white image

    } else if (command == "swap") {
        std::string channel1 = argv[4];
        std::string channel2 = argv[5];

        if (!is_color(channel1) or !is_color(channel2)) {
            std::cout << "Error  channels can only take values in { red , "
                         "green , blue }"
                      << std::endl;
            return 1;
        }
        Channel c1 = channel_from_str(channel1);
        Channel c2 = channel_from_str(channel2);

        // Step 2.2
        // RGBImage image = ... complete me ... ; // load the RGB image
        // RGBImage image_with_swapped_channels = ... complete me ... ; // swap
        // c1 and c2 of image and store the result

        // ... complete me ... -> save your modified image

    } else {
        std::cout << "Unknown command" << std::endl;
    }
    return 0;
}