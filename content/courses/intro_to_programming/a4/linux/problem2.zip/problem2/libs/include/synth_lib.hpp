#pragma once

#include <cstdint>
#include <string>
#include <vector>
#if defined(_WIN32) || defined(WIN32) || defined(__CYGWIN__) || \
    defined(__MINGW32__) || defined(__BORLANDC__)
#ifdef WIN_EXPORT_LIB
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __declspec(dllimport)
#endif
#else
#define EXPORT
#endif

/**
 * @brief enum to use to represent musical notes
 *
 */
enum class Note { C, Cs, D, Ds, E, F, Fs, G, Gs, A, As, B };

using Audio = std::vector<float>;

/**
 * @brief Creates an audio containing the note \p note of the \p octave'th
 * octave. The note lasts for \p duration_sec seconds and contains \p harmonics
 * harmonics.
 *
 *
 * @param note
 * @param octave
 * @param duration_sec
 * @param harmonics
 * @return An audio
 */
EXPORT
Audio create_note(Note    note,
                  uint8_t octave,
                  float   duration_sec,
                  int     harmonics = 6);

/**
 * @brief Appends to \p audio an audio containing the note \p note of the \p
 * octave'th octave lasting for \p duration_sec seconds and containing \p
 * harmonics harmonics.
 *
 *
 * @param audio
 * @param note
 * @param octave
 * @param duration_sec
 * @param harmonics
 */
EXPORT
void append_note(Audio&  audio,
                 Note    note,
                 uint8_t octave,
                 float   duration_sec,
                 int     harmonics);

/**
 * @brief Appends \p audio2 at the end of \p audio1.
 *
 */
EXPORT
void concatenate_sounds(Audio& audio1, const Audio& audio2);

/**
 * @brief Saves the audio \p audio in the file \p filename. The filename has to
 * be a .wav.
 *
 * @param filename
 * @param audio
 */
EXPORT
void save_audio(const std::string filename, const Audio& audio);