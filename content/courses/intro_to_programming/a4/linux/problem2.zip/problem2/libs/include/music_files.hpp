#pragma once

#include <string>
#include <synth_lib.hpp>
#include <vector>

/**
 * @brief Reads a music file and stores the information in the different
 * vectors.
 *
 * @details A music file contains lines, and each line contains a triplet: note
 * height duration. Example: A 4 1 C 5 1 E 5 1
 *
 * Encodes A4 C5 E5, each played for one second.
 * @param filename
 * @param notes
 * @param octaves
 * @param durations
 */
EXPORT
void parse_music_file(const std::string  filename,
                      std::vector<Note>& notes,
                      std::vector<int>&  octaves,
                      std::vector<int>&  durations);