#include <synth_lib.hpp>
#include <iostream>

int main(int argc, char** argv) {

    return 0;
}