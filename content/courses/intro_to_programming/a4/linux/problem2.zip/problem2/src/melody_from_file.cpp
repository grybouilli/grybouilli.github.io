#include <synth_lib.hpp>
#include <music_files.hpp>
#include <iostream>

int main(int argc, char** argv) {

    return 0;
}