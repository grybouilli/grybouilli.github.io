#include <image_manips.hpp>
#include <iostream>

int main(int argc, char** argv) {

    return 0;
}